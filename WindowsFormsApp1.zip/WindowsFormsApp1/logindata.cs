﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class logindata
    {
        public static string uid = "", uname = ""; //登陆者的id姓名
    }
}
